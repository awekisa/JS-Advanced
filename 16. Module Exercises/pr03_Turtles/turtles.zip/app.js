let Turtle = require('./turtle');
let WaterTurtle = require('./waterTurtle');
let EvkodianTurtle = require('./evkodianTurtle');
let GalapagosTurtle = require('./galapagusTurtle');
let NinjaTurtle = require('./ninjaTurtle');

result.Turtle = Turtle;
result.WaterTurtle = WaterTurtle;
result.EvkodianTurtle = EvkodianTurtle;
result.GalapagosTurtle = GalapagosTurtle;
result.NinjaTurtle = NinjaTurtle;


// let t = new Turtle("shit", "shit", "shit");
// console.log(t.toString())

// let testWaterTurtle = new WaterTurtle("Michelangelo", 18, "male", "Sewer");
// let testGalapagosTurtle = new GalapagosTurtle("Raphael", 18, "male");
// let testEvkodianTurtle = new EvkodianTurtle("Donatello", 18, "male", 100);
// let testNinjaTurtle = new NinjaTurtle("Leonardo", 18, "male", "Blue", "Yamato");
//
// console.log(testWaterTurtle.toString());
//
// console.log(testGalapagosTurtle.toString());
//
// console.log(testEvkodianTurtle.toString());
//
// testNinjaTurtle.grow(5);
// console.log(testNinjaTurtle.age)
