let Entity = require('./Entity');
let Person = require('./person');
let Student = require('./student');
let Dog = require('./dog');

let things = {
    Entity: Entity,
    Dog: Dog,
    Person: Person,
    Student: Student
}


module.exports = things