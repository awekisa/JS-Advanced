let functions = require('./pr04_Inheritance');

result.Entity = functions.Entity;
result.Person = functions.Person;
result.Student = functions.Student;
result.Dog = functions.Dog;

